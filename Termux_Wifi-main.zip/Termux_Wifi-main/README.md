## Termux-Wifi
> apa itu termux-wifi?

> Termux-Wifi adalah tools: mematikan wifi siapapun (Tanpa Admin), Hack Password wifi (ONLY ADMIN)

> Token: https://cararegistrasi.com/6yEQz
## Instalasi
```
$ cd
$ pkg update -y && pkg upgrade -y
$ pkg install git -y
$ pkg install python -y
$ git clone https://github.com/DARK-02/Termux_Wifi
```
## execute
```python3
$ cd Termux_Wifi
$ python3 run.py
```
